using System.Text;
using System.Collections.Generic;
using System.Linq;
using System;

namespace DEOS
{
	public class ChessTest
	{
		public static void Main(string[] args)
		{
			var logger = NLog.LogManager.GetCurrentClassLogger();
			logger.Info("Program Starting...");
			try
			{
				Console.WriteLine(Run());
				logger.Info("Program ended...");
			}
			catch (Exception e) {
				logger.Error("Program ended with error: {0}", e);
			}
		}
		public static bool Run()
		{
			DEOS deos = new DEOS();
			return deos.Run();
		}
	}
}