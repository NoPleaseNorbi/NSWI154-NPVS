
#include <string>

#include <syslog.h>

#include "server.h"

int main (int argc, char ** argv) {
  openlog("NPVS", LOG_CONS | LOG_PID, LOG_USER);
  syslog(LOG_INFO, "Program is starting...");
  if ((argc > 1) && std::string (argv[1]) == "-u") {
      udp_server ();
  } else{
      tcp_server ();
  }
  closelog();
}
