
#include <string>

#include <syslog.h>
#include "client.h"

int main (int argc, char ** argv) {
  openlog("NPVS", LOG_CONS | LOG_PID, LOG_USER);
  syslog(LOG_INFO, "Program is starting damn");

  if ((argc > 1) && std::string (argv[1]) == "-u") {
      udp_client ();
  } else{
      tcp_client ();
  }
  closelog();
}
